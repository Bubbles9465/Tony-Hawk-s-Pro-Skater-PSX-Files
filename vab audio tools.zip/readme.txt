Mumbly(usb@wanadoo.fr) Presents:

Psx Audio Utilities V0.1
------------------------

Long ago I wanted to know if it was possible to
ripp off sound samples from my psx cdroms.
Just like i did in the past on my ("still used")
Amiga with some ripper software.

Now that my knowledge of the psx has improved,
i decided to code a couple of Psx Audio Ripping utils.

These utilities are quite simple :

Vab Ripper
**********

VAB files are multisample files from sOnY Psx.
Vab ripper is a Psx VAB(Audio Bank) data grabber, 
it seeks any psx file given as an argument for 
suitable VAB audio datas. 
If it finds those datas, it saves the datas as .VAB files.
If there are several VAB datas in the psx file you are
analysing, then several .VAB files will be created/saved.
Those files contain a header that describe how the
infos are organized and then the raw audio samples,
those raw audio samples are also called VAG.
VAB files contain audio compressed samples so you can't
play the samples until you don't decompress them.
The decompression utility only works on pure psx waveform
datas also known as VAGs so you neet to convert your
ripped VAB files into VAG files by using the Vab2Vag util.

Vab 2 Vag
*********

Converts VAB files to several .VAG, in fact it extracts
the raw Psx audio samples out from .VAB files. If it
finds that the VAB has multiple samples inside, it saves
several .VAG files.
The VAG are the pure audio files in Psx compressed file
format, to convert those files to audible pcm file format
you need to use the Vag_Depack utility.

Vag_Depack
**********

Not written by me, just compiled from the sources of
BitMaster i found on the net, this is a handy utility
that enables to convert .VAG files to raw 16 bit
mono unsigned little indian sound sample.
Then you can load those files into any wave editor
and then listen to the result: a bunch of sounds
from your favorite psx games !


Other cool features
*******************

With those small utilities you can even find and
listen to sounds and fx that you have never heard
before from you games !

Enjoy.

Mumbly.

---------------------------------------------------------
NOTE1: I found that games from Namco for example have
a different format (custom?) for some VAB datas(not all),
they cannot be managed by VabRipper and are skipped....
---------------------------------------------------------
NOTE2: I cannot be taken responsible of anything occuring
when you use the freeware utilities i programmed.
---------------------------------------------------------
NOTE3: Use this utilities on original games only !